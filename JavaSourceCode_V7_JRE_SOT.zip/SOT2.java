package com.sot;

import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.BorderLayout;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.geom.Rectangle2D;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Timer;
import java.util.TimerTask;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.factories.FormFactory;
import javax.swing.AbstractAction;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.BasicStroke;
/*
import javax.swing.text.AbstractDocument;
import javax.swing.text.BoxView;
import javax.swing.text.ComponentView;
import javax.swing.text.Element;
import javax.swing.text.IconView;
import javax.swing.text.LabelView;
import javax.swing.text.ParagraphView;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledEditorKit;
import javax.swing.text.View;
import javax.swing.text.ViewFactory;
*/
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.Toolkit;

public class SOT2 {
	private JFrame frame;
	CardLayout cardLayout;
	JPanel panel;
	private JTextField tfSubject;
	private JTextField tfAge;
	private JTextField tfAllowedTime;
	String[][] stims={
		{"-1","bell","tree","drum","306","Before"},
		{"-2","drum","traffic light","wheel","57","After"},
		{"-3","bell","tree","barrel","326","After"},
		{"-4","trash can","drum","bell","49","After"},
		{"1","wheel","barrel","traffic light","143","None"},
		{"2","drum","tree","wheel","249","None"},
		{"3","traffic light","drum","trash can","93","None"},
		{"4","drum","bell","wheel","165","None"},
		{"5","traffic light","tree","barrel","318","None"},
		{"6","traffic light","bell","wheel","250","None"},
		{"7","barrel","trash can","bell","333","None"},
		{"8","trash can","bell","traffic light","268","None"},
		{"9","wheel","traffic light","tree","266","None"},
		{"10","barrel","drum","wheel","41","None"},
		{"11","tree","bell","trash can","25","None"},
		{"12","drum","trash can","barrel","151","None"},
	};
	String instructionText[]={
		"Imaging you are standing at the <b>[Center]</b> and facing the <b>[Top]</b>.<p>",
		"Point to the <b>[Target]</b>.<p>",
		"Here is a sample item that has the correct answer drawn in. Practice inputting your response using the mouse. To practice marking your answer, click on the arrow circle and a line will appear. Drag the line around the arrow circle using the mouse to the desired response. Match your answer to the correct answer shown. Can you satisfy yourself that this answer is the correct answer?<p>",
		"Please press ENTER when finished."
	};
	enum Panels { Experiment,Instructions,Stim,InstructionsTest,InstructionsTraining,EndOfExperiment,ShowFinished }
	int[] panels={ 0,1,2,3,4,5 };
	int[] order=new int[4+12];
	PrintWriter data;
	int trialIx=0;
	boolean madeEst=false,afterTrial=false,busy=false;
	int estX,estY;
	int estAngle,angularError;
	int[] estimates=new int[12];
	int trialsFinished=0,trialsFinishedIn5=0;
	double avg,stdev;
	long tStart;
	String instructionStr,extraInstructionStr;
	//-these vars need to be global so myJPanel can use them
	int iw=653,ih=407,m=12,r=200;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					final SOT2 window=new SOT2();
					//TODO I don't think there is a solution for this
					//while this code refocuses to this window whenever the focus is lost, it doesn't prevent windows
					//from tabbing through the other applications; EPrime has the same problem, so just be aware that
					//pressing Alt-Tab is a problem
					
					//solved: also, when you press TAB, ENTER doesn't work unless use Shift-TAB back; TAB moves focus
					//back-TAB doesn't work in the JAR file???
					//making the graphic (label) and instruction text unfocusable and the circle (panel_1) focusable solves the tab problem
					window.frame.addWindowFocusListener(new WindowFocusListener() {
						public void windowGainedFocus(WindowEvent e) {
						}
						public void windowLostFocus(WindowEvent e) {
							//window.frame.requestFocus();
						}
					});
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the application.
	 */
	public SOT2() {
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame=new JFrame();
		frame.setAlwaysOnTop(true);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setUndecorated(true);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		panel = new JPanel();
		frame.getContentPane().add(panel, "name_18549721582173");
		panel.setLayout(new CardLayout(0, 0));
		
		JPanel ExperimentContainer = new JPanel();
		ExperimentContainer.setName("Experiment");
		panel.add(ExperimentContainer, ExperimentContainer.getName());//"name_5609021942722");
		GridBagLayout gbl_ExperimentContainer = new GridBagLayout();
		gbl_ExperimentContainer.columnWidths = new int[]{450, 0};
		gbl_ExperimentContainer.rowHeights = new int[]{300, 0};
		gbl_ExperimentContainer.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_ExperimentContainer.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		ExperimentContainer.setLayout(gbl_ExperimentContainer);
		
		final JPanel Experiment = new JPanel();
		Experiment.setLayout(new FormLayout(new ColumnSpec[] {
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				FormFactory.RELATED_GAP_COLSPEC,
				FormFactory.DEFAULT_COLSPEC,
				ColumnSpec.decode("4dlu:grow"),},
			new RowSpec[] {
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,
				FormFactory.RELATED_GAP_ROWSPEC,
				FormFactory.DEFAULT_ROWSPEC,}));
		
		JLabel lblSubject = new JLabel("Subject (1..999):");
		lblSubject.setHorizontalAlignment(SwingConstants.RIGHT);
		Experiment.add(lblSubject, "2, 2, right, default");
		
		tfSubject = new JTextField();
		tfSubject.setText("1");
		Experiment.add(tfSubject, "4, 2, fill, default");
		tfSubject.setColumns(10);
		
		JLabel lblAge = new JLabel("Age (0..150):");
		lblAge.setHorizontalAlignment(SwingConstants.RIGHT);
		Experiment.add(lblAge, "2, 4, right, default");
		
		tfAge = new JTextField();
		tfAge.setText("0");
		Experiment.add(tfAge, "4, 4, fill, default");
		tfAge.setColumns(10);
		
		JLabel lblGendermalefemale = new JLabel("Gender (male,female):");
		lblGendermalefemale.setHorizontalAlignment(SwingConstants.RIGHT);
		Experiment.add(lblGendermalefemale, "2, 6, right, default");
		
		final JComboBox<String> cbGender = new JComboBox<String>();
		cbGender.setMaximumRowCount(2);
		cbGender.setModel(new DefaultComboBoxModel<String>(new String[] {"male", "female"}));
		cbGender.setSelectedIndex(0);
		Experiment.add(cbGender, "4, 6, fill, default");
		
		JLabel lblAllowedTime = new JLabel("Allowed Time (1..60 minutes):");
		lblAllowedTime.setHorizontalAlignment(SwingConstants.RIGHT);
		Experiment.add(lblAllowedTime, "2, 8, right, default");
		
		tfAllowedTime = new JTextField();
		tfAllowedTime.setText("5");
		Experiment.add(tfAllowedTime, "4, 8, fill, default");
		tfAllowedTime.setColumns(10);
		
		JLabel lblOrderrandomsequential = new JLabel("Order (Random,Sequential):");
		lblOrderrandomsequential.setHorizontalAlignment(SwingConstants.RIGHT);
		Experiment.add(lblOrderrandomsequential, "2, 10, right, default");
		
		final JComboBox<String> cbOrder = new JComboBox<String>();
		cbOrder.setMaximumRowCount(2);
		cbOrder.setModel(new DefaultComboBoxModel<String>(new String[] {"Random", "Sequential"}));
		cbOrder.setSelectedIndex(0);
		Experiment.add(cbOrder, "4, 10, fill, default");
		GridBagConstraints gbc_Experiment = new GridBagConstraints();
		gbc_Experiment.gridx = 0;
		gbc_Experiment.gridy = 0;
		ExperimentContainer.add(Experiment, gbc_Experiment);
		
		JButton btnCancel = new JButton("Cancel");
		Experiment.add(btnCancel, "2, 12, center, default");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		JButton btnOk = new JButton("OK");
		Experiment.add(btnOk, "4, 12, center, default");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Experiment.getActionMap().get("nextCard").actionPerformed(null);
			}
		});
		Dimension d=Toolkit.getDefaultToolkit().getScreenSize();
		
		JPanel Instructions = new JPanel();
		Instructions.setName("Instructions");
		panel.add(Instructions, Instructions.getName());//"name_18591930978733");
		Instructions.setLayout(new BorderLayout(0, 0));
		
		JTextPane txtpn_1 = new JTextPane();
		txtpn_1.setHighlighter(null);
		txtpn_1.setEditable(false);
		txtpn_1.setContentType("text/html");
		txtpn_1.setText("<body style=\"font-family:Arial,Helvetica,sans-serif;font-size:1.0625em;\r\ntext-align:left;margin:10px 0px 50px 50px\">\r\n<p><b>Spatial Orientation Test</b></p>\r\n<p>This is a test of your ability to imagine different perspectives or orientations in space. In this task, you will see a picture of an array of objects with a statement below it, together with an \u201Carrow circle\u201D. You will be asked to imagine that you are standing at one object in the array and facing another object. Your task is to draw a line showing the direction to a third object from this perspective. On each trial, you will be asked to imagine standing at a different first object, facing a different second object, and then to draw a line to a different third object.</p>\r\n<p>You respond by \u201Cdrawing\u201D a line on the arrow circle using the computer mouse. The center of the arrow circle represents your imagined location (at the first object) and the vertical arrow represents your imagined perspective (facing the second object). You need to draw the direction to a third object from this facing direction.</p>\r\n<p>Look at the sample item below. In this example you are asked to imagine that you are standing at the bell facing the tree. Your task is to draw a line indicating the direction to the drum. In the sample item this line has been drawn for you. In the test items, your task is to draw this line on the arrow circle using the computer mouse. Can you see that if you were at the bell facing the tree the drum would be in the direction shown by the dotted line? Please ask the experimenter now if you have any questions about what you are required to do.</p>\r\n<p>Now you will begin practicing on the computer.</p>\r\n<p>Press the SPACE BAR to continue.</p>\r\n</body>\r\n");
		Instructions.add(txtpn_1, BorderLayout.CENTER);
		
		JTextPane txtpn_1a = new JTextPane();
		txtpn_1a.setHighlighter(null);
		txtpn_1a.setEditable(false);
		txtpn_1a.setContentType("text/html");
		txtpn_1a.setText("<body>\r\n<p style=\"text-align:center;position:absolute;bottom:0px;\">\r\n<img src=\"jar:file:sot2.jar!/resources/InstructionImage.png\"></p>\r\n</body>\r\n");
		Instructions.add(txtpn_1a, BorderLayout.SOUTH);
		
		JPanel StimAndText = new JPanel();
		StimAndText.setBackground(new Color(255, 255, 255));
		StimAndText.setName("Stim");
		panel.add(StimAndText, StimAndText.getName());//"name_13672856258882");
		StimAndText.setLayout(new BorderLayout(0, 0));
		
		final JTextPane txtpnInstructionText = new JTextPane();
		txtpnInstructionText.setHighlighter(null);
		txtpnInstructionText.setEditable(false);
		txtpnInstructionText.setContentType("text/html");
		txtpnInstructionText.setText("<body style=\"font-family:Arial,Helvetica,sans-serif;font-size:1.0625em;text-align:left;margin:0px 50px 0px 50px\"><font face=\"Arial\" size=\"5\">\r\n<p>Imagine you are standing at the <b>[Center]</b> and facing the <b>[Top]</b>. Point to the <b>[Target]</b>.</p>\r\n[Extra]\r\n<p>Please press ENTER when finished.</p>\r\n</body>");
		StimAndText.add(txtpnInstructionText, BorderLayout.SOUTH);
		instructionStr=txtpnInstructionText.getText();
		extraInstructionStr="<p>Here is a sample item that has the correct answer drawn in. Practice inputting your response using the mouse. To practice marking your answer, click on the arrow circle and a line will appear. Drag the line around the arrow circle using the mouse to the desired response. Match your answer to the correct answer shown. Can you satisfy yourself that this answer is the correct answer?</p>";
		//-set to remaining vertical space after the image is scaled (see below)
		//txtpnInstructionText.setPreferredSize(new Dimension(1024,300));
		
		JLabel lblNewLabel_1 = new JLabel("");
		//compute size for bitmap based on monitor resolution
		//-these vars need to be global so myJPanel can use them
		//int iw=653,ih=407,m=12,r=200;
		double scale=(d.getWidth()-4*m-2*r)/iw;
		if (scale>(0.75*d.getHeight()/ih)) {
			scale=0.75*d.getHeight()/ih;
			r=(int)((d.getWidth()-4*m-scale*iw)/2);
		}
		iw=(int)(scale*iw);
		ih=(int)(scale*ih);
		txtpnInstructionText.setPreferredSize(new Dimension((int)d.getWidth(),(int)(d.getHeight()-ih)));
		//TODO SCALE_DEFAULT or _SMOOTH
		lblNewLabel_1.setIcon(new ImageIcon(new ImageIcon(SOT2.class.getResource("/resources/stim.png")).getImage().getScaledInstance(iw,ih,Image.SCALE_DEFAULT)));
		lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setPreferredSize(new Dimension(iw,ih));
		StimAndText.add(lblNewLabel_1, BorderLayout.WEST);
		
		final JPanel panel_1 = new MyJPanel();
		panel_1.setBackground(Color.WHITE);
		StimAndText.add(panel_1, BorderLayout.CENTER);
		//TODO solve TAB/back-TAB problem when ENTER is pressed after TAB during trials
		//set panel_1 as only focusable control
		txtpnInstructionText.setFocusable(false);
		lblNewLabel_1.setFocusable(false);
		panel_1.setFocusable(true);
		MouseListener ml=new MouseListener() {
			public void mouseClicked(MouseEvent e) {
			}
			public void mousePressed(MouseEvent e) {
				if (busy) {
					return;
				}
				//show line at new angle
				estX=e.getX();
				estY=e.getY();
				madeEst=true;
				panel_1.repaint();
			}
			public void mouseReleased(MouseEvent e) {
			}
			public void mouseEntered(MouseEvent e) {
			}
			public void mouseExited(MouseEvent e) {
			}
		};
		panel_1.addMouseListener(ml);
		panel_1.addMouseMotionListener(new MouseMotionListener() {
			public void mouseDragged(MouseEvent e) {
				//allow line at new angle to move as mouse is dragged
				estX=e.getX();
				estY=e.getY();
				madeEst=true;
				panel_1.repaint();
			}
			public void mouseMoved(MouseEvent e) {
			}
		});
/*		
		//key listeners don't work like mouse listeners because of focus issues; use inputMap/actionMap (see below) instead
		KeyListener kl=new KeyListener() {
			public void keyTyped(KeyEvent e) {
			}
			public void keyPressed(KeyEvent e) {
				System.out.println("Stim keyPressed");
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					//next trial
					trialIx=trialIx+1;
					if (trialIx==0) {
						
					}
					if (trialIx<4) {
						
					} else if (trialIx>(4+12)) {
						panel.getActionMap().get("nextCard").actionPerformed(null);
					}
				}
			}
			public void keyReleased(KeyEvent e) {
			}
		};
		panel.addKeyListener(kl);
*/		
		JPanel InstructionsTest = new JPanel();
		InstructionsTest.setName("InstructionsTest");
		panel.add(InstructionsTest, InstructionsTest.getName());//"name_18600410856535");
		InstructionsTest.setLayout(new BorderLayout(0, 0));
		
		final JTextPane txtpn_2 = new JTextPane();
		//TODO Arial 20 matches EPrime's Arial 16 for plain text
		//txtpn_2.setFont(new Font("Arial", Font.PLAIN, 20));
		//txtpn_2.setEditorKit(new MyEditorKit());
		txtpn_2.setHighlighter(null);
		txtpn_2.setEditable(false);
		txtpn_2.setContentType("text/html");
		txtpn_2.setText("<style type=\"text/css\">\r\n  body {text-align:center;font-family:Arial,Helvetica,sans-serif;font-size:16px}\r\n</style>\r\n<body>\r\n<p>Now you will do the test. There are 12 items on this test. You will have [AllowedTime] minutes to complete these items.</p>\r\n\r\n<p>Please try to respond accurately, but do not spend too much time on any one item.</p>\r\n\r\n<p>Ask the experimenter if you have any final questions about this task.</p>\r\n\r\n<p>When you are ready to start, please let the experimenter know.</p>\r\n</body>\r\n");
		InstructionsTest.add(txtpn_2,BorderLayout.CENTER);
		JTextPane txtpn_2a=new JTextPane();
		txtpn_2a.setPreferredSize(new Dimension(txtpn_2.getPreferredSize().width,((int)d.getHeight()-txtpn_2.getPreferredSize().height)/2));
		InstructionsTest.add(txtpn_2a,BorderLayout.NORTH);
		
		JPanel InstructionsTraining = new JPanel();
		InstructionsTraining.setName("InstructionsTraining");
		panel.add(InstructionsTraining, InstructionsTraining.getName());//"name_10869847342339");
		InstructionsTraining.setLayout(new BorderLayout(0, 0));
		
		JTextPane txtpn_5 = new JTextPane();
		txtpn_5.setHighlighter(null);
		txtpn_5.setEditable(false);
		txtpn_5.setContentType("text/html");
		txtpn_5.setText("<style type=\"text/css\">\r\n  body {text-align:center;font-family:Arial,Helvetica,sans-serif;font-size:16px}\r\n</style>\r\n<body>\r\n<p>Now you will do three practice trials. When each trial appears, move the line to indicate your answer.</p>\r\n\r\n<p>Once you have entered your answer the correct answer will be shown in red.</p>\r\n\r\n<p>Press SPACE BAR to see the first practice trial.</p>\r\n</body>\r\n");
		InstructionsTraining.add(txtpn_5, BorderLayout.CENTER);
		JTextPane txtpn_5a=new JTextPane();
		txtpn_5a.setPreferredSize(new Dimension(txtpn_5.getPreferredSize().width,((int)d.getHeight()-txtpn_5.getPreferredSize().height)/2));
		InstructionsTraining.add(txtpn_5a,BorderLayout.NORTH);
		
		JPanel EndOfExperiment = new JPanel();
		EndOfExperiment.setName("EndOfExperiment");
		panel.add(EndOfExperiment, EndOfExperiment.getName());//"name_6511802596178");
		EndOfExperiment.setLayout(new BorderLayout(0, 0));
		
		JTextPane txtpn_3 = new JTextPane();
		txtpn_3.setHighlighter(null);
		txtpn_3.setEditable(false);
		txtpn_3.setContentType("text/html");
		txtpn_3.setText("<style type=\"text/css\">\r\n  body {text-align:center;font-family:Arial,Helvetica,sans-serif;font-size:16px}\r\n</style>\r\n<body>\r\n<p>You have now completed this task.</p>\r\n\r\n<p>Please call the experimenter.</p>\r\n</body>\r\n");
		EndOfExperiment.add(txtpn_3, BorderLayout.CENTER);
		JTextPane txtpn_3a=new JTextPane();
		txtpn_3a.setPreferredSize(new Dimension(txtpn_3.getPreferredSize().width,((int)d.getHeight()-txtpn_3.getPreferredSize().height)/2));
		EndOfExperiment.add(txtpn_3a,BorderLayout.NORTH);
		
		JPanel ShowFinished = new JPanel();
		ShowFinished.setName("ShowFinished");
		panel.add(ShowFinished, ShowFinished.getName());//"name_18623770476454");
		ShowFinished.setLayout(new BorderLayout(0, 0));
		
		final JTextPane txtpn_4 = new JTextPane();
		txtpn_4.setHighlighter(null);
		txtpn_4.setEditable(false);
		txtpn_4.setContentType("text/html");
		txtpn_4.setText("<style type=\"text/css\">\r\n  body {text-align:center;font-family:Arial,Helvetica,sans-serif;font-size:16px}\r\n</style>\r\n<body>\r\n<p>[FinishedIn5] trials were completed in 5 minutes or less.</p>\r\n\r\n<p>[FinishedInTotal] trials out of 12 were completed in [TotalTimeInMinutes] minutes.</p>\r\n\r\n<p>Average Angular Error: [Avg]</p>\r\n<p>Standard Deviation: [Stdev]</p>\r\n</body>\r\n");
		ShowFinished.add(txtpn_4, BorderLayout.CENTER);
		JTextPane txtpn_4a=new JTextPane();
		txtpn_4a.setPreferredSize(new Dimension(txtpn_4.getPreferredSize().width,((int)d.getHeight()-txtpn_4.getPreferredSize().height)/2));
		ShowFinished.add(txtpn_4a,BorderLayout.NORTH);
		
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cardLayout=(CardLayout)panel.getLayout();
		Experiment.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("SPACE"),"nextCard");
		Experiment.getActionMap().put("nextCard",new AbstractAction() {
			private static final long serialVersionUID=1L;
			public void actionPerformed(ActionEvent e) {
				try {
					data=new PrintWriter(new FileWriter("SOTData"+tfSubject.getText()+".TXT"));
				} catch (IOException e1) {
					e1.printStackTrace();
					System.exit(-1);
				}
				data.println("Subject\t"+tfSubject.getText());
				data.println("Age\t"+tfAge.getText());
				data.println("Gender\t"+cbGender.getSelectedItem());
				data.println("AllowedTime\t"+tfAllowedTime.getText());
				data.println("Order\t"+cbOrder.getSelectedItem());
				data.println("Subject\tTrial\tCenter\tTop\tTarget\tTargetAngle\tEstimateAngle\tAngularError");
				//create trial order for both, practice & test trials
				for (int j=0;j<4+12;j++) {
					order[j]=j;
					if ((j>=4) & cbOrder.getSelectedItem().equals("Random")) {
						int k,r;
						do {
							r=(int)(4+Math.random()*12);
							for (k=4;k<j;k++) {
								if (r==order[k]) {
									r=-1;
									break;
								}
							}
						} while (r==-1);
						order[j]=r;
					}
				}
				txtpn_2.setText(txtpn_2.getText().replaceFirst("\\[AllowedTime\\]",tfAllowedTime.getText()));
				//cardLayout.next(panel);
				cardLayout.show(panel,"Instructions");
				panel.requestFocusInWindow();
			}
		});
		StimAndText.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("ENTER"),"nextTrial");
		StimAndText.getActionMap().put("nextTrial",new AbstractAction() {
			private static final long serialVersionUID=1L;
			public void actionPerformed(ActionEvent e) {
				if (busy) {
					return;
				}
				busy=true;
				if ((trialIx>=4) && madeEst) {
					data.println(tfSubject.getText()+"\t"+stims[order[trialIx]][0]+"\t"+stims[order[trialIx]][1]+"\t"+stims[order[trialIx]][2]+"\t"+stims[order[trialIx]][3]+"\t"+stims[order[trialIx]][4]+"\t"+estAngle+"\t"+angularError);
				}
				if ((trialIx>=4) && madeEst) {
					estimates[trialIx-4]=angularError;
				}
				new Thread() {
					@Override
					public void run() {
						if (!madeEst) {
							JOptionPane.showMessageDialog(frame,"Please make an estimate with the mouse before pressing Enter");
							frame.requestFocus();
							busy=false;
							return;
						}
						//next trial
						if ((trialIx>=1)&(trialIx<=3)) {
							afterTrial=true;
							panel_1.repaint();
	            			try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						}
						madeEst=false;
						trialIx=trialIx+1;
						if ((trialIx>4) && (trialIx<=(4+12))) {
    						trialsFinished++;
    						if ((System.currentTimeMillis()-tStart)<300000) {
    							trialsFinishedIn5++;
    						}
    						//System.out.println(trialsFinished+" "+trialsFinishedIn5);
						}
						if (trialIx<(4+12)) {
							if (trialIx!=0) {
								extraInstructionStr="";
							}
							txtpnInstructionText.setText(instructionStr.replaceFirst("\\[Center\\]",stims[order[trialIx]][1]).replaceFirst("\\[Top\\]",stims[order[trialIx]][2]).replaceFirst("\\[Target\\]",stims[order[trialIx]][3]).replaceFirst("\\[Extra\\]",extraInstructionStr));
							panel_1.repaint();
						}
						if (trialIx==1) {
							//cardLayout.next(panel);
							//cardLayout.next(panel);
							cardLayout.show(panel,"InstructionsTraining");
							panel.requestFocusInWindow();
						} else if (trialIx==4) {
							//cardLayout.next(panel);
							cardLayout.show(panel,"InstructionsTest");
							panel.requestFocusInWindow();
						} else if (trialIx>=(4+12)) {
							//cardLayout.next(panel);
							//cardLayout.next(panel);
							//cardLayout.next(panel);
							cardLayout.show(panel,"EndOfExperiment");
							panel.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).remove(KeyStroke.getKeyStroke("SPACE"));
							panel.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("shift BACK_QUOTE"),"nextCard");
							panel.requestFocusInWindow();
						}
						busy=false;
					}
				}.start();
			}
		});
		panel.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(/*"SPACE" or */KeyEvent.VK_SPACE,0),"nextCard");
		panel.getActionMap().put("nextCard",new AbstractAction() {
			private static final long serialVersionUID=1L;
			public void actionPerformed(ActionEvent e) {
				for (int i=0;i<panel.getComponentCount();i++) {
					//System.out.println("i:"+i+" "+panel.getComponent(i).getName()+" "+panel.getComponent(i).isVisible());
					if (panel.getComponent(i).isVisible()) {
    					if (i==Panels.Experiment.ordinal()) {
    						Experiment.getActionMap().get("nextCard").actionPerformed(null);
    					} else if (i==Panels.Instructions.ordinal()) {
    						//cardLayout.next(panel);
    						cardLayout.show(panel,"Stim");
    						panel.requestFocusInWindow();
    						madeEst=false;
							txtpnInstructionText.setText(instructionStr.replaceFirst("\\[Center\\]",stims[order[trialIx]][1]).replaceFirst("\\[Top\\]",stims[order[trialIx]][2]).replaceFirst("\\[Target\\]",stims[order[trialIx]][3]).replaceFirst("\\[Extra\\]",extraInstructionStr));
							//System.out.println(txtpnInstructionText.getText());
    					} else if (i==Panels.Stim.ordinal()) {
    						//you get here if SPACE is pressed in the instruction card that precedes the trials
    						//so doing nothing here is the appropriate thing
    						//System.out.println("Error: stim card selected; should never get here!!!");
    					} else if (i==Panels.InstructionsTest.ordinal()) {
    						tStart=System.currentTimeMillis();
    						new Timer().schedule(new TimerTask() {
								@Override
								public void run() {
									//write remaining stims
									for (;trialIx<(4+12);trialIx++) {
										data.println(tfSubject.getText()+"\t"+stims[order[trialIx]][0]+"\t"+stims[order[trialIx]][1]+"\t"+stims[order[trialIx]][2]+"\t"+stims[order[trialIx]][3]+"\t"+stims[order[trialIx]][4]+"\t"+""+"\t"+90);
										estimates[trialIx-4]=90;
									}
									//cardLayout.next(panel);
									//cardLayout.next(panel);
									cardLayout.show(panel,"EndOfExperiment");
									panel.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).remove(KeyStroke.getKeyStroke("SPACE"));
									panel.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("shift BACK_QUOTE"),"nextCard");
									panel.requestFocusInWindow();
								}
    						},Integer.parseInt(tfAllowedTime.getText())*60000l);
    						//cardLayout.previous(panel);
    						cardLayout.show(panel,"Stim");
    						panel.requestFocusInWindow();
    					} else if (i==Panels.InstructionsTraining.ordinal()) {
    						//cardLayout.previous(panel);
    						//cardLayout.previous(panel);
    						cardLayout.show(panel,"Stim");
    						panel.requestFocusInWindow();
    					} else if (i==Panels.EndOfExperiment.ordinal()) {
    						int sum=0,sumsq=0;
    						for (int j=0;j<12;j++) {
    							sum+=estimates[j];
    						}
    						avg=sum/12d;
    						for (int j=0;j<12;j++) {
    							sumsq+=Math.pow(estimates[j]-avg,2);
    						}
    						stdev=Math.sqrt(sumsq/(12d-1));
    						data.println("Average"+"\t"+String.format("%4.2f",avg));
    						data.println("Stdev"+"\t"+String.format("%4.2f",stdev));
    						txtpn_4.setText(txtpn_4.getText().replaceFirst("\\[FinishedIn5\\]",Integer.toString(trialsFinishedIn5)).replaceFirst("\\[FinishedInTotal\\]",Integer.toString(trialsFinished)).replaceFirst("\\[TotalTimeInMinutes\\]",tfAllowedTime.getText()).replaceFirst("\\[Avg\\]",String.format("%4.2f",avg)).replaceFirst("\\[Stdev\\]",String.format("%4.2f",stdev)));
    						data.close();
    						//cardLayout.next(panel);
    						cardLayout.show(panel,"ShowFinished");
							panel.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).remove(KeyStroke.getKeyStroke("shift BACK_QUOTE"));
							panel.getInputMap(JPanel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("SPACE"),"nextCard");
    						panel.requestFocusInWindow();
    					} else if (i==Panels.ShowFinished.ordinal()) {
    						System.exit(0);
    					} else {
    						System.out.println("Error: invalid card; should never get here!!!");
    					}
    					break;
					}
				}
			}
		});
	}
	Font MyJPanelFont=new Font("Arial",Font.BOLD,16);
	class MyJPanel extends JPanel {
		private static final long serialVersionUID=1L;
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			String TopStr=stims[order[trialIx]][2];
			String CenterStr=stims[order[trialIx]][1];
			String TargetStr=stims[order[trialIx]][3];
			//TODO target angle attribute is double but program uses integer!!!
			//-use truncated values from list
			int TargetAngle=(int)Double.parseDouble(stims[order[trialIx]][4]);
			g.setFont(MyJPanelFont);
			g.setColor(Color.black);
			g.fillRect(0,0,3,getHeight());
			int cx=getWidth()/2,cy=getHeight()/2;
			//int r=200;
			int x=cx-r,y=cy-r,w=2*r,h=2*r;
			Graphics2D g2=(Graphics2D)g;
			//TODO make circle and line thicker; EPrime uses 2, but 3 looks better in Java
			g2.setStroke(new BasicStroke(3));
			g.drawArc(x,y,w,h,0,360);
			g.drawLine(cx,cy,cx,cy-r);
			int ArrowW=10,ArrowH=20;
			int yOffset=3;
			g.drawLine(cx,cy-r,cx-ArrowW,cy-r+ArrowH);
			g.drawLine(cx,cy-r,cx+ArrowW,cy-r+ArrowH);
			Rectangle2D b=g.getFontMetrics().getStringBounds(TopStr,g);
			g.drawString(TopStr,cx-(int)b.getWidth()/2,cy-r-yOffset);
			b=g.getFontMetrics().getStringBounds(CenterStr,g);
			g.drawString(CenterStr,cx-(int)b.getWidth()/2,cy+(int)b.getHeight());
			b=g.getFontMetrics().getStringBounds(TargetStr,g);
			int a=(360+90-TargetAngle)%360;
			int q=0;
			if (a<90) {
				q=1;
			} else if (a<180) {
				q=2;
			} else if (a<270) {
				q=3;
			} else if (a<360) {
				q=4;
			} else {
				JOptionPane.showMessageDialog(null,"Oops, TargetAngle not in range from 0 to 359");
				a=0;
			}
			//System.out.println("Angle:"+a+" Quadrant:"+q);
			double arad=a*Math.PI/180.0;
			if (!stims[order[trialIx]][5].equals("None")) {
    			x=(int)(r*Math.cos(arad)-0*Math.sin(arad));
    			y=(int)(r*Math.sin(arad)+0*Math.cos(arad));
    			if (stims[order[trialIx]][5].equals("After")) {
    				if (afterTrial) {
        				//for practice trials with feedback after the trial, show a red line for 1 second
        				g.setColor(Color.RED);
            			g.drawLine(cx,cy,cx+x,cy-y);
            			g.setColor(Color.BLACK);
            			afterTrial=false;
    				}
    			} else {
    				g.drawLine(cx,cy,cx+x,cy-y);
        			if (q==1) {
        				y=-y-yOffset;
        			} else if (q==2) {
        				x=x-(int)b.getWidth();
        				y=-y-yOffset;
        			} else if (q==3) {
        				x=x-(int)b.getWidth();
        				y=-y+(int)b.getHeight();
        			} else {
        				y=-y+(int)b.getHeight();
        			}
        			g.drawString(TargetStr,cx+x,cy+y);
        			//g.drawRect(cx+x,cy+y-(int)b.getHeight(),(int)b.getWidth(),(int)b.getHeight());
    			}
			}
			//draw line for estimate
			if (madeEst) {
    			arad=Math.atan2(-estY+cy,estX-cx);
    			x=(int)(r*Math.cos(arad)-0*Math.sin(arad));
    			y=(int)(r*Math.sin(arad)+0*Math.cos(arad));
    			g.drawLine(cx,cy,cx+x,cy-y);
    			estAngle=(360+90-(int)(arad/Math.PI*180))%360;
    			angularError=Math.abs(estAngle-TargetAngle);
    			if (angularError>180) {
    				angularError=360-angularError;
    			}
			}
		}
	}
}
/*
//This works to vertically center text in a text/plain JTextPane; it doesn't work for text/html
class MyEditorKit extends StyledEditorKit {
	private static final long serialVersionUID=1L;
	public ViewFactory getViewFactory() {
        return new StyledViewFactory();
    }
    static class StyledViewFactory implements ViewFactory {
        public View create(Element elem) {
            String kind = elem.getName();
            //System.out.println(kind);
            if (kind != null) {
                if (kind.equals(AbstractDocument.ContentElementName)) {
                    return new LabelView(elem);
                } else if (kind.equals(AbstractDocument.ParagraphElementName)) {
                    return new ParagraphView(elem);
                } else if (kind.equals(AbstractDocument.SectionElementName)) {
                    return new CenteredBoxView(elem, View.Y_AXIS);
                } else if (kind.equals(StyleConstants.ComponentElementName)) {
                    return new ComponentView(elem);
                } else if (kind.equals(StyleConstants.IconElementName)) {
                    return new IconView(elem);
                }
            }
            return new LabelView(elem);
        }
    }
}
class CenteredBoxView extends BoxView {
    public CenteredBoxView(Element elem, int axis) {
        super(elem,axis);
    }
    protected void layoutMajorAxis(int targetSpan, int axis, int[] offsets, int[] spans) {
        super.layoutMajorAxis(targetSpan,axis,offsets,spans);
        int textBlockHeight=0;
        int offset=0;
        for (int i=0;i<spans.length;i++) {
            textBlockHeight+=spans[i];
        }
        offset=(targetSpan-textBlockHeight)/2;
        for (int i=0;i<offsets.length;i++) {
            offsets[i]+=offset;
        }
    }
}    
*/